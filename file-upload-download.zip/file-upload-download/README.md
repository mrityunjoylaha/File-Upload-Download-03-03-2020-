# FileUploadDownload
this is a simple file upload download app built using Node,Express,MongoDB,EJS and few other packages.

Usage

install the dependencies

-- npm install

now run the application

-- node app.js

App run on :http://localhost:3000
